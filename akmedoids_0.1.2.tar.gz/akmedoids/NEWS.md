---
title: "NEWS.md"
author: "geoMADE"
date: "19 April 2019"
output: html_document
---

### R Markdown

'Akmedoids' package updated (Version: v0.1.2)

### Updates:

I editted the vignette in order to display the title. Currently I have "Put the title of your vignette here" on the website (i.e. https://cran.r-project.org/web/packages/akmedoids/). This is totally my mistake.

I am sorry for any inconvenience.

Your faithfully.
Monsuru.
