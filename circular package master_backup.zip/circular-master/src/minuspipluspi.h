
/****************************************************************
*                                                               *
*       AUTHORS : CLAUDIO AGOSTINELLI and ALESSANDRO GAGLIARDI  *
*       AIM : Header of minuspipluspi.c                       	 *
*       DATA : 02 NOVEMBER 2012.                                *
*                                                               *
*****************************************************************/

void MinusPiPlusPiRad(double *,int *);
