#include <R_ext/RS.h>

void F77_NAME(dwrpnorm)(double *dtheta, double *dmu, double *dsd,
                        int *nsize, int *nmu, int *ik, double *dd);
