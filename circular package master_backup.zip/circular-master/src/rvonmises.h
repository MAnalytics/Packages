void rvm(double*, int*, double*, double*);
