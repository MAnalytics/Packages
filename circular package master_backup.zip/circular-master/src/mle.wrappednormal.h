#include <R_ext/RS.h>

void F77_NAME(mlewrpno)(double *dtheta, double *dmu, double *dsd,
                        int *nsize, int *ik, int *im, int *ir,
                        double *dw, double *dwk, double *dwm);
