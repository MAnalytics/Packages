
/****************************************************************
*                                                               *
*       AUTHORS : CLAUDIO AGOSTINELLI and ALESSANDRO GAGLIARDI  *
*       AIM : Header of median.circular.c								 *
*       DATA : 10 NOVEMBER 2012.                                *
*                                                               *
*****************************************************************/

void MedianCircularRad(double*,int*,double*,double *,int *);
double dev(double *,double,int *);

