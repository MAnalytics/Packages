
/******************************************************************
*																						*
*	AUTHORS : CLAUDIO AGOSTINELLI and ALESSANDRO GAGLIARDI			*
*	AIM : Header of mean.circular.c   										*
*	DATA : 18 OCTOBER 2012.														*
*																						*
*******************************************************************/

void MeanCircularRad(double*,int*,double*);
