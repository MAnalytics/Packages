/******************************************************************
* AUTHORS CLAUDIO AGOSTINELLI
* AIM : Header of WeightedMeanCircular.c
* DATA : 12 May 2015
*******************************************************************/

void WeightedMeanCircularRad(double*,double*,int*,double*);
