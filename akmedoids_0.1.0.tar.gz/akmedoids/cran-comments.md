---
title: "cran-comments.md"
author: "geoMADE"
date: "19 March 2019"
output: html_document
---

## R CMD check results
There were no ERRORs or WARNINGs. 

