#' @title sample population (denominator) data
#' @description Simulated denominator data with missing observation
#' @name population
#' @docType data
#' @usage population
#' @format A matrix
#' @keywords datasets

NULL
