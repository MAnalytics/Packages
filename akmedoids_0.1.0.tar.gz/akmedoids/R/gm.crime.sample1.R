#' @title Sample crime dataset
#' @description Simulated crime dataset with missing values.
#' @name gm.crime.sample1
#' @docType data
#' @usage gm.crime.sample1
#' @format A matrix
#' @keywords datasets

NULL
