#' @title Longitudinal dataset
#' @description Simulated longitudinal datasets with missing values ('NA', 'Inf' and 'Null')
#' @name gm.crime.sample1
#' @docType data
#' @usage gm.crime.sample1
#' @format A matrix
#' @keywords datasets

NULL
