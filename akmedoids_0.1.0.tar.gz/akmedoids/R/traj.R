#' @title Longitudinal dataset
#' @description Simulated longitudinal datasets with missing values (\code{NA}, \code{Inf}, \code{null})
#' @name traj
#' @docType data
#' @usage traj
#' @format A matrix
#' @keywords datasets

NULL
