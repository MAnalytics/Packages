## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo=FALSE, include=FALSE------------------------------------------
require(knitr)
library(flextable)
library(kableExtra)
col1 <- c("1", "2","3","4")
col2 <- c("`dataImputation`","`outlierDetect`","`wSpaces`", "`props`")
col3 <- c("Data imputation for longitudinal data","Outlier detection and replacement","Whitespaces removal", "Conversion of counts (or rates) to 'Proportion'")
col4 <- c("Calculates any missing entries (`NA`, `Inf`, `null`) in a longitudinal data, according to a specified method","Identifies outlier observations in the data, and replace or remove them","Removes all the leading and trailing whitespaces in a longitudinal data","Converts counts or rates observation to 'proportion'")
tble <- data.frame(col1, col2, col3, col4)
tble <- tble

## ---- results='asis', echo=FALSE, tidy.opts=list(width.cutoff=50)--------
knitr::kable(tble, caption = "`Data manipulation` functions", col.names = c("SN","Function","Title","Description")) %>%
  kable_styling(full_width = F) %>%
  column_spec(1, bold = T, border_right = T) %>%
  column_spec(2, width = "8em", background = "white") %>%
  column_spec(3, width = "12em", background = "white") %>%
  column_spec(4, width = "16em", background = "white")#%>%
  #row_spec(3:5, bold = T, color = "white", background = "#D7261E")

## ---- eval=TRUE----------------------------------------------------------
#reading the data
traj <- read.table(file="C:/demo/gm.crime.sample1.csv", sep=",", head=TRUE)
#preview the data
head(traj)
nrow(traj) #no. of rows
ncol(traj) #no. of columns

## ---- include=TRUE-------------------------------------------------------
#install 'devtools' package
#install.packages("devtools")
#library(devtools)
#devtools::install_github("manalytics/packages/akmedoids")

## ---- fig.show='hold'----------------------------------------------------
plot(1:10)
plot(10:1)
#Data preparation
#Clustering
#Results 
#Individual trajectories
#Inequalities 
#Discussions
#Conclusion


## ---- echo=FALSE, results='asis'-----------------------------------------
knitr::kable(head(mtcars, 10))

## ---- echo=FALSE---------------------------------------------------------
require(knitr)
col1 <- c("City", "Abidjan","Accra","Amman")
col2 <- c("Optimized HDH","217","281","26398")
col3 <- c("Standard HDH","0","0","37056")
col4 <- c("Heating Demand [W/(�C x Capita)]", "0.0","0.0","28.3")
col5 <- c("Heating Energy [kWh/(capita x yr)]","0","0","469.68")
col6 <- c("Threshold Temperature","23.3","24","17.6")
col7 <- c("Optimized CDH","31781","25264","32198")
col8 <- c("Standard CDH", "59398","58895","22059")
col9 <- c("Cooling Demand [W/(�C x capita)]", "1.67", "2.83", "45.72")
col10 <- c("Cooling Energy [kWh/(capita x yr)]", "53", "143.56", "1256.62")
tble2 <- data.frame(col1, col2, col3, col4, col5, col6, col7, col8, col9, col10)

colnames(tble2) <- tble2[1,]
tble <- tble2[2:4,]

