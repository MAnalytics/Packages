################################################################################
#
# CURRENTLY NO TESTS
#

## fit_spline
## UNTESTED

## AUC
## UNTESTED

## plot_helper
## UNTESTED

## get_data
## UNTESTED

## get_data.psp_model
## UNTESTED

## Predict
## UNTESTED

## smooth
## UNTESTED

## set_spline_options
## UNTESTED

## predict
## UNTESTED

## plot
## UNTESTED

## lines
## UNTESTED

## add_parameters
## UNTESTED

## as
## UNTESTED

## n_knots
## UNTESTED
