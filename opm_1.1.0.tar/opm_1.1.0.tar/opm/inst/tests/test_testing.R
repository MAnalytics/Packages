

################################################################################
#
# NOTHING TO TEST
#
# 'testing.R' should only contain helper functions that are invoked during
# testing anyway
#


## source_location
## UNTESTED

## testfile_dir
## UNTESTED

## objects_for_testing
## UNTESTED

