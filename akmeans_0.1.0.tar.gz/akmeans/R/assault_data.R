#' @title Sample crime (assault) dataset
#' @description Simulated crime dataset with missing values.
#' @name assault_data
#' @docType data
#' @usage assault_data
#' @format A matrix
#' @keywords datasets

NULL
