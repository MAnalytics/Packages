#' @title Greater Manchester crime data aggregated at the LSOA geographical level
#'
#' @description #sample crime data for testing
#' @name GM_crime_data
#' @docType data
#' @usage GM_crime_data
#' @format A matrix
#' @keywords datasets
NULL
