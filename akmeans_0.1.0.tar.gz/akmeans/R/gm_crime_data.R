#' @title Greater Manchester crime data aggregated at the LSOA geographical level data (Source: data.police.uk)
#' @description #GGGGGGGGG
#' @name gm_crime_data
#' @docType data
#' @usage gm_crime_data
#' @format A matrix
#' @keywords datasets
NULL
