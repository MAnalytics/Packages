---
title: "NEWS.md"
authors: "geoMADE"
date: "25 December 2019"
output: html_document
---

### R Markdown

'Akmedoids' package updated (Version: v0.1.3)

### Updates:

1. Add arguments 'digits' and 'scale' to the 'props' function. 
2. Add argument 'crit' to the 'akmedoids.clust' function
3. Add new function 'elbowPoint'

Your faithfully.
Monsuru.
